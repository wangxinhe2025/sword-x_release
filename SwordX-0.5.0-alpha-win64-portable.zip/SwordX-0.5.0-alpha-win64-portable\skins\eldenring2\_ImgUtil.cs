﻿using System;
using System.Drawing;
using System.Drawing.Imaging;
using System.Runtime.InteropServices;

public static class ImgUtil {
  public static bool IsBg(byte r, byte g, byte b) {
    int mx = Math.Max(r, Math.Max(g, b));
    int mn = Math.Min(r, Math.Min(g, b));
    return (mx - mn < 22 && mx > 165);
  }

  public static Bitmap MakeTransparentBg(Bitmap src) {
    Bitmap dst = new Bitmap(src.Width, src.Height, PixelFormat.Format32bppArgb);
    var rect = new Rectangle(0, 0, src.Width, src.Height);
    BitmapData sdata = src.LockBits(rect, ImageLockMode.ReadOnly, PixelFormat.Format32bppArgb);
    BitmapData ddata = dst.LockBits(rect, ImageLockMode.WriteOnly, PixelFormat.Format32bppArgb);
    int bytes = Math.Abs(sdata.Stride) * src.Height;
    byte[] sbuf = new byte[bytes];
    byte[] dbuf = new byte[bytes];
    Marshal.Copy(sdata.Scan0, sbuf, 0, bytes);
    for (int y = 0; y < src.Height; y++) {
      int row = y * sdata.Stride;
      for (int x = 0; x < src.Width; x++) {
        int i = row + x * 4;
        byte b = sbuf[i], g = sbuf[i+1], r = sbuf[i+2], a = sbuf[i+3];
        if (IsBg(r, g, b)) {
          dbuf[i] = dbuf[i+1] = dbuf[i+2] = dbuf[i+3] = 0;
        } else {
          dbuf[i] = b; dbuf[i+1] = g; dbuf[i+2] = r; dbuf[i+3] = a;
        }
      }
    }
    Marshal.Copy(dbuf, 0, ddata.Scan0, bytes);
    src.UnlockBits(sdata);
    dst.UnlockBits(ddata);
    return dst;
  }

  public static Bitmap TightCrop(Bitmap src) {
    var rect = new Rectangle(0, 0, src.Width, src.Height);
    BitmapData data = src.LockBits(rect, ImageLockMode.ReadOnly, PixelFormat.Format32bppArgb);
    int minx = src.Width, miny = src.Height, maxx = -1, maxy = -1;
    byte[] buf = new byte[Math.Abs(data.Stride) * src.Height];
    Marshal.Copy(data.Scan0, buf, 0, buf.Length);
    for (int y = 0; y < src.Height; y++) {
      int row = y * data.Stride;
      for (int x = 0; x < src.Width; x++) {
        if (buf[row + x * 4 + 3] > 20) {
          if (x < minx) minx = x;
          if (y < miny) miny = y;
          if (x > maxx) maxx = x;
          if (y > maxy) maxy = y;
        }
      }
    }
    src.UnlockBits(data);
    if (maxx < 0) return (Bitmap)src.Clone();
    int pad = 2;
    minx = Math.Max(0, minx - pad);
    miny = Math.Max(0, miny - pad);
    maxx = Math.Min(src.Width - 1, maxx + pad);
    maxy = Math.Min(src.Height - 1, maxy + pad);
    int w = maxx - minx + 1, h = maxy - miny + 1;
    Bitmap dst = new Bitmap(w, h, PixelFormat.Format32bppArgb);
    using (Graphics g = Graphics.FromImage(dst)) {
      g.DrawImage(src, new Rectangle(0,0,w,h), new Rectangle(minx,miny,w,h), GraphicsUnit.Pixel);
    }
    return dst;
  }

  public static Bitmap Darken(Bitmap src, double factor) {
    Bitmap dst = new Bitmap(src.Width, src.Height, PixelFormat.Format32bppArgb);
    var rect = new Rectangle(0, 0, src.Width, src.Height);
    BitmapData sdata = src.LockBits(rect, ImageLockMode.ReadOnly, PixelFormat.Format32bppArgb);
    BitmapData ddata = dst.LockBits(rect, ImageLockMode.WriteOnly, PixelFormat.Format32bppArgb);
    int bytes = Math.Abs(sdata.Stride) * src.Height;
    byte[] sbuf = new byte[bytes];
    byte[] dbuf = new byte[bytes];
    Marshal.Copy(sdata.Scan0, sbuf, 0, bytes);
    for (int i = 0; i < bytes; i += 4) {
      dbuf[i+3] = sbuf[i+3];
      if (sbuf[i+3] == 0) { dbuf[i]=dbuf[i+1]=dbuf[i+2]=0; continue; }
      dbuf[i]   = (byte)Math.Min(255, sbuf[i] * factor);
      dbuf[i+1] = (byte)Math.Min(255, sbuf[i+1] * factor);
      dbuf[i+2] = (byte)Math.Min(255, sbuf[i+2] * factor);
    }
    Marshal.Copy(dbuf, 0, ddata.Scan0, bytes);
    src.UnlockBits(sdata); dst.UnlockBits(ddata);
    return dst;
  }

  public static Bitmap Brighten(Bitmap src, double add) {
    Bitmap dst = new Bitmap(src.Width, src.Height, PixelFormat.Format32bppArgb);
    var rect = new Rectangle(0, 0, src.Width, src.Height);
    BitmapData sdata = src.LockBits(rect, ImageLockMode.ReadOnly, PixelFormat.Format32bppArgb);
    BitmapData ddata = dst.LockBits(rect, ImageLockMode.WriteOnly, PixelFormat.Format32bppArgb);
    int bytes = Math.Abs(sdata.Stride) * src.Height;
    byte[] sbuf = new byte[bytes];
    byte[] dbuf = new byte[bytes];
    Marshal.Copy(sdata.Scan0, sbuf, 0, bytes);
    for (int i = 0; i < bytes; i += 4) {
      dbuf[i+3] = sbuf[i+3];
      if (sbuf[i+3] == 0) { dbuf[i]=dbuf[i+1]=dbuf[i+2]=0; continue; }
      dbuf[i]   = (byte)Math.Min(255, sbuf[i] + add * 0.4);
      dbuf[i+1] = (byte)Math.Min(255, sbuf[i+1] + add * 0.85);
      dbuf[i+2] = (byte)Math.Min(255, sbuf[i+2] + add);
    }
    Marshal.Copy(dbuf, 0, ddata.Scan0, bytes);
    src.UnlockBits(sdata); dst.UnlockBits(ddata);
    return dst;
  }
}
