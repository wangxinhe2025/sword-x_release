using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Runtime.InteropServices;

public class Blob {
    public int X, Y, W, H, Area;
}

public static class OpaqueExtract {
    // Treat baked checkerboard / empty dark panel as "transparent"
    static bool IsIgnore(byte r, byte g, byte b) {
        int mx = Math.Max(r, Math.Max(g, b));
        int mn = Math.Min(r, Math.Min(g, b));
        // checkerboard / light gray matte
        if (mx - mn < 30 && mx > 110) return true;
        // empty dark panel (parts_2 lower wash)
        if (mx < 48 && mx - mn < 22) return true;
        return false;
    }

    // Stricter: require solid UI (metal/gold/icon), drop soft glow fringes
    static bool IsSolid(byte r, byte g, byte b) {
        if (IsIgnore(r, g, b)) return false;
        int mx = Math.Max(r, Math.Max(g, b));
        int mn = Math.Min(r, Math.Min(g, b));
        int sat = mx - mn;
        // gold / warm metal
        if (r > 90 && g > 60 && r >= g && g >= b - 10 && sat > 25) return true;
        // dark stone/metal face
        if (mx < 90 && sat < 40) return true;
        // bright white glow core / icon
        if (mx > 200 && sat < 50) return true;
        // mid textured button face
        if (mx >= 48 && mx <= 160 && sat < 55) return true;
        return false;
    }

    public static List<Blob> FindBlobs(string path, int minArea, bool solidOnly) {
        using (var bmp = new Bitmap(path)) {
            int w = bmp.Width, h = bmp.Height;
            var rect = new Rectangle(0, 0, w, h);
            var data = bmp.LockBits(rect, ImageLockMode.ReadOnly, PixelFormat.Format32bppArgb);
            int stride = Math.Abs(data.Stride);
            byte[] buf = new byte[stride * h];
            Marshal.Copy(data.Scan0, buf, 0, buf.Length);
            bmp.UnlockBits(data);

            bool[] mask = new bool[w * h];
            for (int y = 0; y < h; y++) {
                int row = y * stride;
                for (int x = 0; x < w; x++) {
                    int i = row + x * 4;
                    byte b = buf[i], g = buf[i + 1], r = buf[i + 2];
                    mask[y * w + x] = solidOnly ? IsSolid(r, g, b) : !IsIgnore(r, g, b);
                }
            }

            // erode once to kill thin glow bridges
            bool[] er = new bool[w * h];
            for (int y = 1; y < h - 1; y++) {
                for (int x = 1; x < w - 1; x++) {
                    int p = y * w + x;
                    if (!mask[p]) continue;
                    if (mask[p - 1] && mask[p + 1] && mask[p - w] && mask[p + w]) er[p] = true;
                }
            }

            bool[] vis = new bool[w * h];
            var blobs = new List<Blob>();
            int[] qx = new int[w * h];
            int[] qy = new int[w * h];

            for (int y = 0; y < h; y++) {
                for (int x = 0; x < w; x++) {
                    int start = y * w + x;
                    if (!er[start] || vis[start]) continue;
                    int qh = 0, qt = 0;
                    qx[qt] = x; qy[qt] = y; qt++;
                    vis[start] = true;
                    int minx = x, maxx = x, miny = y, maxy = y, area = 0;
                    while (qh < qt) {
                        int cx = qx[qh], cy = qy[qh]; qh++;
                        area++;
                        if (cx < minx) minx = cx;
                        if (cy < miny) miny = cy;
                        if (cx > maxx) maxx = cx;
                        if (cy > maxy) maxy = cy;
                        for (int dy = -1; dy <= 1; dy++) {
                            for (int dx = -1; dx <= 1; dx++) {
                                if (dx == 0 && dy == 0) continue;
                                int nx = cx + dx, ny = cy + dy;
                                if (nx < 0 || ny < 0 || nx >= w || ny >= h) continue;
                                int np = ny * w + nx;
                                if (vis[np] || !er[np]) continue;
                                vis[np] = true;
                                qx[qt] = nx; qy[qt] = ny; qt++;
                            }
                        }
                    }
                    if (area >= minArea) {
                        int pad = 4;
                        minx = Math.Max(0, minx - pad);
                        miny = Math.Max(0, miny - pad);
                        maxx = Math.Min(w - 1, maxx + pad);
                        maxy = Math.Min(h - 1, maxy + pad);
                        blobs.Add(new Blob { X = minx, Y = miny, W = maxx - minx + 1, H = maxy - miny + 1, Area = area });
                    }
                }
            }
            blobs.Sort((a, b) => a.X != b.X ? a.X.CompareTo(b.X) : a.Y.CompareTo(b.Y));
            return blobs;
        }
    }

    public static void ExtractBlob(string srcPath, Blob blob, string outPath, bool solidOnly) {
        using (var src = new Bitmap(srcPath))
        using (var dst = new Bitmap(blob.W, blob.H, PixelFormat.Format32bppArgb)) {
            var srect = new Rectangle(0, 0, src.Width, src.Height);
            var drect = new Rectangle(0, 0, blob.W, blob.H);
            var sdata = src.LockBits(srect, ImageLockMode.ReadOnly, PixelFormat.Format32bppArgb);
            var ddata = dst.LockBits(drect, ImageLockMode.WriteOnly, PixelFormat.Format32bppArgb);
            int ss = Math.Abs(sdata.Stride), ds = Math.Abs(ddata.Stride);
            byte[] sbuf = new byte[ss * src.Height];
            byte[] dbuf = new byte[ds * blob.H];
            Marshal.Copy(sdata.Scan0, sbuf, 0, sbuf.Length);
            for (int y = 0; y < blob.H; y++) {
                int sy = blob.Y + y;
                for (int x = 0; x < blob.W; x++) {
                    int sx = blob.X + x;
                    int si = sy * ss + sx * 4;
                    int di = y * ds + x * 4;
                    byte b = sbuf[si], g = sbuf[si + 1], r = sbuf[si + 2];
                    bool keep = solidOnly ? IsSolid(r, g, b) : !IsIgnore(r, g, b);
                    if (keep) {
                        dbuf[di] = b; dbuf[di + 1] = g; dbuf[di + 2] = r; dbuf[di + 3] = 255;
                    } else {
                        dbuf[di] = dbuf[di + 1] = dbuf[di + 2] = dbuf[di + 3] = 0;
                    }
                }
            }
            Marshal.Copy(dbuf, 0, ddata.Scan0, dbuf.Length);
            src.UnlockBits(sdata);
            dst.UnlockBits(ddata);
            Directory.CreateDirectory(Path.GetDirectoryName(outPath));
            dst.Save(outPath, ImageFormat.Png);
        }
    }

    public static void ScaleTo(string srcPath, string outPath, int size) {
        using (var src = new Bitmap(srcPath))
        using (var dst = new Bitmap(size, size, PixelFormat.Format32bppArgb))
        using (var g = Graphics.FromImage(dst)) {
            g.Clear(Color.Transparent);
            g.InterpolationMode = System.Drawing.Drawing2D.InterpolationMode.HighQualityBicubic;
            float scale = Math.Min((float)size / src.Width, (float)size / src.Height);
            int dw = Math.Max(1, (int)(src.Width * scale));
            int dh = Math.Max(1, (int)(src.Height * scale));
            g.DrawImage(src, (size - dw) / 2, (size - dh) / 2, dw, dh);
            Directory.CreateDirectory(Path.GetDirectoryName(outPath));
            dst.Save(outPath, ImageFormat.Png);
        }
    }
}
