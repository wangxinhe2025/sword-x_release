﻿Sword-X Audio Player  portable (no installer)
Version: 0.5.0 alpha
https://www.swordx.net/

[Run]
1. Unzip the whole folder (do not copy SwordX.exe alone).
2. Double-click SwordX.exe.
3. Windows 10/11 x64. VC runtime and FFmpeg DLLs are included.

[Layout]
  SwordX.exe             player
  SwordXSkinEditor.exe  skin editor
  *.dll                  FFmpeg + VC runtime (do not delete)
  skins\                 bundled skins
  locales\               UI languages
  scripts\               Lua DSP / window effects

[Data]
Settings, playlists, cover and lyrics cache:
  %LOCALAPPDATA%\wxhPlayer
Delete this folder to uninstall. Delete the AppData path to wipe data.

[Custom skins]
Put a wxh-skin/1 folder or zip into:
  this-folder\skins\
  or %LOCALAPPDATA%\wxhPlayer\skins\
User skins override bundled skins.

---- 中文 ----
解压整个目录后双击 SwordX.exe。无需安装。
配置与缓存：%LOCALAPPDATA%\wxhPlayer
自定义皮肤可放到本目录 skins\ 或上述用户目录。
