Texture2D imageTexture : register(t0);
SamplerState imageSampler : register(s0);

cbuffer SkinShaderConstants : register(b1) {
    float2 viewportSize;
    float2 componentSize;
    float2 componentOrigin;
    float timeSeconds;
    float opacity;
};

struct PSInput {
    float4 position : SV_POSITION;
    float2 uv : TEXCOORD0;
    float4 color : COLOR0;
    float2 maskPosition : TEXCOORD1;
    float2 maskHalfSize : TEXCOORD2;
    float4 maskData : TEXCOORD3;
};

float hash21(float2 p) {
    p = frac(p * float2(123.34, 456.21));
    p += dot(p, p + 45.32);
    return frac(p.x * p.y);
}

float crystalSparkle(
    float2 pixelPosition,
    float cellSize,
    float2 drift,
    float elapsed,
    float seedOffset) {
    float2 grid = pixelPosition / cellSize + drift * elapsed;
    float2 cell = floor(grid);
    float2 local = frac(grid) - 0.5;

    float seed = hash21(cell + seedOffset);
    float angle = seed * 6.2831853;
    float sineValue = sin(angle);
    float cosineValue = cos(angle);
    float2 shard = float2(
        local.x * cosineValue - local.y * sineValue,
        local.x * sineValue + local.y * cosineValue);

    float shardDistance =
        abs(shard.x) * lerp(0.78, 1.34, seed) +
        abs(shard.y) * lerp(1.05, 1.72, hash21(cell + 7.13));
    float antialiasWidth = max(fwidth(shardDistance), 0.010);
    float body = 1.0 - smoothstep(
        0.33 - antialiasWidth, 0.33 + antialiasWidth, shardDistance);
    float inner = 1.0 - smoothstep(
        0.18 - antialiasWidth, 0.18 + antialiasWidth, shardDistance);
    float fracturedEdge = saturate(body - inner);

    // Softer flash curve than transport sun-flow: peaks more often so narrow
    // decor strips still read as lively ice rather than sparse ticks.
    float phase = elapsed * lerp(1.35, 2.35, hash21(cell + 19.47))
                + seed * 6.2831853;
    float flash = pow(saturate(0.5 + 0.5 * sin(phase)), 4.8);
    float blade = pow(saturate(1.0 - abs(shard.x + shard.y * 0.24) * 7.6), 2.6);
    float crossBlade = pow(
        saturate(1.0 - abs(shard.y - shard.x * 0.18) * 9.0), 3.4);

    return flash * (
        inner * (0.52 + blade * 0.44 + crossBlade * 0.39) +
        fracturedEdge * 1.15) * 0.78;
}

float4 main(PSInput input) : SV_TARGET {
    float4 pixel = imageTexture.Sample(imageSampler, input.uv) * input.color;
    if (pixel.a <= 0.0001) {
        return pixel;
    }

    // Decor strips are narrow; mix screen-space continuity with denser local
    // cells so sparkles do not disappear into a 25–33px column.
    float2 screen = input.position.xy / max(viewportSize.y, 1.0);
    float2 localPx = input.position.xy - componentOrigin;
    float elapsed = timeSeconds * 1.85;
    float scaleBasis = max(viewportSize.y / 1080.0, 0.55);

    float coarse = crystalSparkle(
        input.position.xy, 11.0 * scaleBasis, float2(-0.32, 0.11), elapsed, 3.17);
    float fine = crystalSparkle(
        input.position.xy, 5.2 * scaleBasis, float2(-0.48, 0.18), elapsed, 31.73);
    float localSpark = crystalSparkle(
        localPx, 4.0 * scaleBasis, float2(0.22, -0.55), elapsed * 1.15, 71.09);

    // Twin traveling beams: one diagonal sun wash, one vertical column sweep
    // that reads clearly on tall ice ornaments.
    float sunPhase = frac(screen.x * 0.58 + screen.y * 0.27 - timeSeconds * 0.20);
    float sunbeam = pow(saturate(1.0 - abs(sunPhase - 0.5) * 2.55), 2.0);
    float columnUv = localPx.y / max(componentSize.y, 1.0);
    float columnPhase = frac(columnUv * 0.85 - timeSeconds * 0.42);
    float columnBeam = pow(saturate(1.0 - abs(columnPhase - 0.5) * 3.1), 1.7);

    float beam = saturate(sunbeam * 0.62 + columnBeam * 0.72);
    float sparkle =
        (coarse * 0.50 + fine * 0.38 + localSpark * 0.42) * (0.62 + beam * 1.40);
    float flowingSheen = beam * 0.16 + sunbeam * 0.06;

    float3 straight = pixel.rgb / max(pixel.a, 0.0001);
    float iceWeight = saturate(
        (straight.b - straight.r) * 2.15 +
        (straight.g - straight.r) * 0.86 + 0.32);
    float3 iceTint = float3(0.44, 0.91, 1.0);
    float3 sunlight = float3(0.91, 0.97, 1.0);
    float3 rimCyan = float3(0.54, 0.94, 1.0);

    straight = saturate(
        straight * (0.90 + flowingSheen * 0.62) +
        iceTint * sparkle * iceWeight * 0.98 +
        sunlight * fine * beam * 0.30 +
        rimCyan * localSpark * columnBeam * 0.40);

    return float4(straight * pixel.a, pixel.a);
}
