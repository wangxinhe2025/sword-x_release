Texture2D imageTexture : register(t0);
SamplerState imageSampler : register(s0);

cbuffer SkinShaderConstants : register(b1) {
    float2 viewportSize;
    float2 componentSize;
    float2 componentOrigin;
    float timeSeconds;
    float opacity;
};

struct PSInput {
    float4 position : SV_POSITION;
    float2 uv : TEXCOORD0;
    float4 color : COLOR0;
    float2 maskPosition : TEXCOORD1;
    float2 maskHalfSize : TEXCOORD2;
    float4 maskData : TEXCOORD3;
};

float hash21(float2 p) {
    p = frac(p * float2(123.34, 456.21));
    p += dot(p, p + 45.32);
    return frac(p.x * p.y);
}

float crystalSparkle(
    float2 pixelPosition,
    float cellSize,
    float2 drift,
    float elapsed,
    float seedOffset) {
    float2 grid = pixelPosition / cellSize + drift * elapsed;
    float2 cell = floor(grid);
    float2 local = frac(grid) - 0.5;

    float seed = hash21(cell + seedOffset);
    float angle = seed * 6.2831853;
    float sineValue = sin(angle);
    float cosineValue = cos(angle);
    float2 shard = float2(
        local.x * cosineValue - local.y * sineValue,
        local.x * sineValue + local.y * cosineValue);

    // Each cell contains one small, differently oriented ice fragment.
    float shardDistance =
        abs(shard.x) * lerp(0.82, 1.28, seed) +
        abs(shard.y) * lerp(1.10, 1.65, hash21(cell + 7.13));
    float antialiasWidth = max(fwidth(shardDistance), 0.012);
    float body = 1.0 - smoothstep(
        0.29 - antialiasWidth, 0.29 + antialiasWidth, shardDistance);
    float inner = 1.0 - smoothstep(
        0.20 - antialiasWidth, 0.20 + antialiasWidth, shardDistance);
    float fracturedEdge = saturate(body - inner);

    // Random phase and speed keep the fragments sparkling independently while
    // the deliberately slow oscillation prevents a distracting strobe effect.
    float phase = elapsed * lerp(1.05, 1.75, hash21(cell + 19.47))
                + seed * 6.2831853;
    float flash = pow(saturate(0.5 + 0.5 * sin(phase)), 7.0);
    float blade = pow(saturate(1.0 - abs(shard.x + shard.y * 0.24) * 8.5), 3.0);
    float crossBlade = pow(
        saturate(1.0 - abs(shard.y - shard.x * 0.18) * 10.0), 4.0);

    return flash * (
        inner * (0.42 + blade * 0.36 + crossBlade * 0.34) +
        fracturedEdge * 0.95);
}

float4 main(PSInput input) : SV_TARGET {
    float4 pixel = imageTexture.Sample(imageSampler, input.uv) * input.color;
    if (pixel.a <= 0.0001) {
        return pixel;
    }

    // Screen-space placement makes one field of fragments flow continuously
    // through the whole transport group instead of restarting on every button.
    float2 screen = input.position.xy / max(viewportSize.y, 1.0);
    float elapsed = timeSeconds * 1.52;
    float scaleBasis = max(viewportSize.y / 1080.0, 0.55);
    float coarse = crystalSparkle(
        input.position.xy, 15.0 * scaleBasis, float2(-0.25, 0.085), elapsed, 3.17);
    float fine = crystalSparkle(
        input.position.xy, 7.0 * scaleBasis, float2(-0.39, 0.14), elapsed, 31.73);

    // A wide diagonal sunbeam travels slowly over the fragments. Ice outside the
    // beam still has a faint glint, while fragments under it flare briefly.
    float sunPhase = frac(screen.x * 0.58 + screen.y * 0.27 - timeSeconds * 0.136);
    float sunbeam = pow(saturate(1.0 - abs(sunPhase - 0.5) * 2.85), 2.4);
    float sparkle = (coarse * 0.46 + fine * 0.27) * (0.48 + sunbeam * 1.36);
    float flowingSheen = sunbeam * 0.11;

    // Work in straight-alpha colour, then return to the renderer's premultiplied
    // alpha convention. This prevents glow from leaking outside the PNG shape.
    float3 straight = pixel.rgb / max(pixel.a, 0.0001);
    float iceWeight = saturate(
        (straight.b - straight.r) * 2.35 +
        (straight.g - straight.r) * 0.90 + 0.22);
    float3 iceTint = float3(0.48, 0.88, 1.0);
    float3 sunlight = float3(0.88, 0.97, 1.0);
    straight = saturate(
        straight * (0.945 + flowingSheen * 0.48) +
        iceTint * sparkle * iceWeight +
        sunlight * fine * sunbeam * 0.18);

    return float4(straight * pixel.a, pixel.a);
}
